# Branch Protection Configuration

To complete your workflow, configure these branch protection rules in GitHub:

## Main Branch Protection

**Repository Settings → Branches → Add rule for `main`:**

✅ **Require a pull request before merging**
- Require approvals: 1
- Dismiss stale PR approvals when new commits are pushed
- Require review from code owners (optional)

✅ **Require status checks to pass before merging**
- Require branches to be up to date before merging
- Required status checks:
  - `Code Quality & Standards`
  - `WordPress Integration Tests`
  - `Security Vulnerability Scan`
  - `WordPress Plugin Validation`

✅ **Require conversation resolution before merging**

✅ **Require signed commits** (recommended)

✅ **Require linear history** (optional - prevents merge commits)

✅ **Do not allow bypassing the above settings**

✅ **Restrict pushes that create files**
- Restrict to organization members only

## Develop Branch Protection (if using GitFlow)

**Add rule for `develop`:**

✅ **Require a pull request before merging**
- Require approvals: 1

✅ **Require status checks to pass before merging**
- Same status checks as main branch

## Auto-merge Configuration

**Repository Settings → General:**

✅ **Allow auto-merge**
✅ **Automatically delete head branches**

## Repository Secrets Required

Add these secrets in **Settings → Secrets and variables → Actions:**

- `GITHUB_TOKEN` (automatically provided by GitHub)

## Commands to Enable Pre-commit Hooks

Run these commands in your local repository:

```bash
# Install pre-commit (if not already installed)
pip install pre-commit

# Install the git hook scripts
pre-commit install

# Test the hooks
pre-commit run --all-files
```

## Workflow Summary

1. **Feature Development**: Create feature branch, work locally
2. **Pre-commit**: Hooks auto-fix and validate before commit
3. **Push**: Automatic PR creation with conflict detection
4. **CI/CD**: All quality checks must pass
5. **Review**: Required approvals before merge
6. **Merge**: Automatic release creation and plugin updates

This ensures code quality while preventing broken code from reaching production.