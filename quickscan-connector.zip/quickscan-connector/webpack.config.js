const path = require('path');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');

module.exports = (env, argv) => {
  const isProduction = argv.mode === 'production';

  return {
    entry: {
      // Only include actual frontend assets that will be used by the plugin
      'admin': './assets/js/admin.js',
      'frontend': './assets/js/frontend.js',
    },
    output: {
      path: path.resolve(__dirname, 'assets/dist'),
      filename: '[name].min.js',
      clean: true, // Clean the output directory before each build
    },
    module: {
      rules: [
        {
          test: /\.js$/,
          exclude: /node_modules/,
          use: {
            loader: 'babel-loader',
            options: {
              presets: ['@babel/preset-env']
            }
          }
        },
        {
          test: /\.(scss|css)$/,
          use: [
            MiniCssExtractPlugin.loader,
            'css-loader',
            'sass-loader'
          ]
        }
      ]
    },
    plugins: [
      new MiniCssExtractPlugin({
        filename: '[name].min.css',
      }),
    ],
    optimization: {
      minimize: isProduction,
    },
    externals: {
      // Use WordPress provided libraries instead of bundling them
      'jquery': 'jQuery',
      'wp': 'wp',
    },
    devtool: isProduction ? false : 'source-map',
  };
};